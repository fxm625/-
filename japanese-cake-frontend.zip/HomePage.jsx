import React, { useState } from "react";

export default function HomePage() {
  const cakeNames = [
    "抹茶戚風蛋糕",
    "草莓乳酪塔",
    "紅豆麻糬卷",
    "柚子蜂蜜蛋糕",
    "黑芝麻巴斯克",
    "焙茶瑞士捲"
  ];

  const cakeImages = [
    "https://i.imgur.com/DqMiTba.jpg",
    "https://i.imgur.com/eh9dkr9.jpg",
    "https://i.imgur.com/4gQU0kK.jpg",
    "https://i.imgur.com/XrBbMrb.jpg",
    "https://i.imgur.com/zX2YX8f.jpg",
    "https://i.imgur.com/xOlZzRW.jpg"
  ];

  const [cart, setCart] = useState([]);
  const [showCheckout, setShowCheckout] = useState(false);

  const addToCart = (index) => {
    const item = {
      name: cakeNames[index],
      image: cakeImages[index],
      price: 300
    };
    setCart([...cart, item]);
  };

  const getTotal = () => {
    return cart.reduce((sum, item) => sum + item.price, 0);
  };

  return (
    <div className="min-h-screen bg-pink-50">
      <header className="bg-red-100 py-4 px-6 flex justify-between items-center shadow-md">
        <h1 className="text-xl font-bold text-red-700">日式蛋糕店</h1>
        <nav className="space-x-6">
          <a href="#home" className="text-red-700 font-semibold hover:underline">首頁</a>
          <a href="#about" className="text-red-700 hover:underline">關於我們</a>
          <a href="#products" className="text-red-700 hover:underline">產品</a>
          <a href="#contact" className="text-red-700 hover:underline">聯絡我們</a>
          <a href="#login" className="text-red-700 hover:underline">登入</a>
          <button onClick={() => setShowCheckout(true)} className="text-white bg-red-400 px-3 py-1 rounded hover:bg-red-500">購物車 ({cart.length})</button>
        </nav>
      </header>
      {/* 其他內容略 */}
    </div>
  );
}